A Pen created at CodePen.io. You can find this one at http://codepen.io/imtoobose/pen/Pzqbxq.

 A simple weather app using simpleweather.js, for my freecodecamp project.
All icons from http://ionicons.com