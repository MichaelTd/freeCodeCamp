A Pen created at CodePen.io. You can find this one at http://codepen.io/fleeting/pen/xklfq.

 Full docs can be found at http://simpleweatherjs.com.