A Pen created at CodePen.io. You can find this one at http://codepen.io/janzeteachesit/pen/oBjLRL.

 based on https://seejamescode.github.io/hill-generator/

code and everything originally by: 
James Y Rauhut
https://twitter.com/seejamescode
ATX Designer working for IBM Design.

Totally cool idea & app.  Thanks James for introducing them to me.