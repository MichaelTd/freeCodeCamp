A Pen created at CodePen.io. You can find this one at http://codepen.io/Reggie01/pen/WwNbjg.

 Zipline: Use the Twitchtv JSON API
A zipline from basic front end develpment projects. There are four user stories: 
1. User Story: As a user, I can see whether Free Code Camp is currently streaming on Twitch.tv.
2. User Story: As a user, I can click the status output and be sent directly to the Free Code Camp's Twitch.tv channel.
3. User Story: As a user, if Free Code Camp is streaming, I can see additional details about what they are streaming.
4. Bonus User Story: As a user, I will see a placeholder notification if a streamer has closed their Twitch account. You can verify this works by adding brunofin and comster404 to your array of Twitch streamers.

Souce Code: https://github.com/Reggie01/Zipline/tree/master/Zipline/TwitchtvJSONAPI