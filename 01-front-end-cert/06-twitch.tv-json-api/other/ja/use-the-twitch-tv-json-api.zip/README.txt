A Pen created at CodePen.io. You can find this one at http://codepen.io/jemz/pen/rrpaoB.

 Use the Twitch.tv JSON API for freecodecamp.com