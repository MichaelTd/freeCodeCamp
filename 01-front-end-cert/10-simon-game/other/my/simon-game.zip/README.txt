A Pen created at CodePen.io. You can find this one at http://codepen.io/Khatybov/pen/YqYVbP.

 Simon Game. Uses jQuery. 