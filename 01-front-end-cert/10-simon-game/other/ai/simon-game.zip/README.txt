A Pen created at CodePen.io. You can find this one at http://codepen.io/ayoisaiah/pen/bpPRNJ.

 A Simon Game built as part of the Free Code Camp curriculum.