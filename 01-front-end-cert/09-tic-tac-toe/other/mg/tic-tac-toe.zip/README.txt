A Pen created at CodePen.io. You can find this one at http://codepen.io/Nyxx/pen/24e6b3098a251705f337058a4654e1c7.

 