A Pen created at CodePen.io. You can find this one at http://codepen.io/bonham000/pen/zBENvd.

 The Free Code Camp Dungeon Crawler Challenge, designed to mimic the Free Code Camp educational curriculum itself. Playable on mobile too!