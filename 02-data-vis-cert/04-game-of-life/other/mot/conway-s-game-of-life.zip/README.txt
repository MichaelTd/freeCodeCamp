A Pen created at CodePen.io. You can find this one at http://codepen.io/Tattomoosa/pen/BLqbLW.

 Built with React and Canvas for a freeCodeCamp assignment. Could stand to optimized, but it's already one of the most performant versions i've seen at freeCodeCamp.