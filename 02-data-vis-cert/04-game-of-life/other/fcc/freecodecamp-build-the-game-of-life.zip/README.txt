A Pen created at CodePen.io. You can find this one at http://codepen.io/FreeCodeCamp/pen/reGdqx.

 

Forked from [Philip Michaels](http://codepen.io/Cheezily/)'s Pen [ReactJS Game of Life!](http://codepen.io/Cheezily/pen/RrrbXW/).

Forked from [Free Code Camp](http://codepen.io/FreeCodeCamp/)'s Pen [ReactJS Game of Life!](http://codepen.io/FreeCodeCamp/pen/dGOOrZ/).

Forked from [Jonathan Graham](http://codepen.io/theflametrooper/)'s Pen [ReactJS Game of Life!](http://codepen.io/theflametrooper/pen/dMWzGx/).