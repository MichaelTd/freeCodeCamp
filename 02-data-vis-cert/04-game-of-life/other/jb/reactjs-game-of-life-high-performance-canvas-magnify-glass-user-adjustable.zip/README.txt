A Pen created at CodePen.io. You can find this one at http://codepen.io/jacobBogers/pen/XKpOqx.

 Implementation of simulation "Game of Life" from Mathematician Conway  https://en.wikipedia.org/wiki/Conway%27s_Game_of_Life
