A Pen created at CodePen.io. You can find this one at http://codepen.io/Rafase282/pen/wGdbwp.

 Recipe Box for saving your recipes using markdown for more styling options with image preview and saving to local storage so you can keep your recipes.

Also useful for any kid of information.