A Pen created at CodePen.io. You can find this one at http://codepen.io/roxroy/pen/ryxZbY.

 Build a Recipe Box in react.js