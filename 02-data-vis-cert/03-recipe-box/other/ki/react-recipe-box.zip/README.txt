A Pen created at CodePen.io. You can find this one at http://codepen.io/inkblotty/pen/oxWRme.

 Recipe app that remembers what you've added/deleted through local storage.

Built using React.js